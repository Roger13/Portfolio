﻿using UnityEngine;
using System.Collections;

public class camMovement : MonoBehaviour {

	public Transform position;
	public Camera cam;

	private float i;
	private float speedX;
	private float speedY;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if(Time.time%2 < 1){
			speedY = -Time.deltaTime/10;
		}
		else{
			speedY = Time.deltaTime/10;
		}
		if(Time.time%6 < 3){
			speedX = -Time.deltaTime/10;
		}
		else{
			speedX = Time.deltaTime/10;
		}

		position.Translate(speedX,speedY,0);
		 
	}
}
