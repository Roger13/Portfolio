﻿using UnityEngine;
using System.Collections;

public class pointManager : MonoBehaviour {

	public Sprite jarra0;
	public Sprite jarra1;
	public Sprite jarra2;
	public Sprite jarra3;
	public Sprite jarra4;
	public SpriteRenderer renderer;

	public int points;

	// Use this for initialization
	void Start () {
		renderer.sprite = jarra0;
		points = 0;
	}
	
	// Update is called once per frame
	void Update () {

		if(points >= 100){
			renderer.sprite = jarra4;
		}
		
		else if(points >= 60){
			renderer.sprite = jarra3;
		}
		
		else if(points >= 30){
			renderer.sprite = jarra2;
		}
		
		else if(points >= 10){
			renderer.sprite = jarra1;
		}

		else{
			renderer.sprite = jarra0;
		}

	}
}
