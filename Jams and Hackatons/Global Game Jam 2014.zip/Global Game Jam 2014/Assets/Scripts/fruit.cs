using UnityEngine;
using System.Collections;

public class fruit : MonoBehaviour {
	
	public Sprite dead;				
	public Sprite alive;
	public Sprite hurt;
	public SpriteRenderer renderer;

	public AudioClip squash;
	public AudioClip voice;
	public AudioClip scream;
	
	private bool intact;	// Stores the state of the fruit
	private bool over;		// Stores if the mouse is over the fruit

	private float deathTime; 	// Stores the time since the death

	private pointManager pointMan;		// Reference to the point Manager
	private spawnManager fruitMan;

	// Use this for initialization
	void Start () {
		intact = true;
		over = false;
		pointMan = GameObject.Find("Game Manager").GetComponent<pointManager>();
		fruitMan = GameObject.Find("Game Manager").GetComponent<spawnManager>();
		deathTime = 0;
	}
	
	// Update is called once per frame
	void Update () {

		// Handle the alive state
		if (intact) {
			if (!over) {					
				renderer.sprite = alive;
			} else {
				renderer.sprite = hurt;
			}
		}

		// Handle the destruction of the object
		else{
			deathTime += Time.deltaTime;
			if(deathTime >= 4){
				--fruitMan.fruitNum;
				Destroy(gameObject);
			}
		}

	}

	// Handle the destruction animation
	void OnMouseDown () {
		if(intact){
			renderer.sprite = dead;
			audio.PlayOneShot(squash);
			audio.PlayOneShot(scream);
			pointMan.points += 1;
		}

		intact = false;
	}
	
	// Handle the scream animation
	void OnMouseEnter () {

		over = true;
		if (!audio.isPlaying) {
			audio.clip = voice;
			audio.Play();
		}
	}

	void OnMouseExit () {
		over = false;
	}

}