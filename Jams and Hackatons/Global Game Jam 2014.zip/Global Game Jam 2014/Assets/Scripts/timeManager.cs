﻿using UnityEngine;
using System.Collections;

public class timeManager : MonoBehaviour {

	public TextMesh tempo;
	public float contador;

	// Use this for initialization
	void Start () {
		contador = 0;
	}
	
	// Update is called once per frame
	void Update () {
		contador += Time.deltaTime;

		tempo.text = contador.ToString();

		if(contador >= 60){
			tempo.text = "Juice!";
		}

		if(contador >= 70){
			Application.LoadLevel("Menu");	
		}
	}
}
