﻿using UnityEngine;
using System.Collections;

public class spawnManager : MonoBehaviour {

	public Transform banana;
	public Transform laranja; 
	public Transform maça; 
	public Transform melancia; 
	public Transform morango; 
	public Transform pera; 
	public Transform pessego;
	public Transform pimentao; 

	private Object instantiator;

	public float fruitNum;
	private float fruitInstNum;

	Vector3 CalcPos () {
		// Calculating position vector
		float x, y, z;
		
		x = Random.Range(-9, 9);
		
		if (x < -6) {
			y = Random.Range (0, -5); 
		} else {
			y = Random.Range (-5,4);
		}
		z = y;

		return new Vector3 (x, y, z);
	}

	void createFruit(int type) {
		switch(type){
		case 0:
			Instantiate(banana, CalcPos(), Quaternion.identity);
			break;
		case 1:
			Instantiate(laranja, CalcPos(), Quaternion.identity);
			break;
		case 2:
			Instantiate(maça, CalcPos(), Quaternion.identity);
			break;
		case 3:
			Instantiate(morango, CalcPos(), Quaternion.identity);
			break;
		case 4:
			Instantiate(morango, CalcPos(), Quaternion.identity);
			break;
		case 5:
			Instantiate(pera, CalcPos(), Quaternion.identity);
			break;
		case 6:
			Instantiate(pessego, CalcPos(), Quaternion.identity);
			break;
		case 7:
			Instantiate(pimentao, CalcPos(), Quaternion.identity);
			break;
		case 8:
			Instantiate(melancia, CalcPos(), Quaternion.identity);
			break;
		}	
	}

	// Use this for initialization
	void Start () {

		fruitInstNum = 3;
		fruitNum = 0;

	}
	
	// Update is called once per frame
	void Update () {
		if (fruitNum <= fruitInstNum/2) {
			fruitNum += fruitInstNum;

			for(int i = 0; i < fruitInstNum; ++i){
				createFruit (Random.Range(0,7));
			}

			fruitInstNum = 3*fruitInstNum/2;
		}
	}
}
