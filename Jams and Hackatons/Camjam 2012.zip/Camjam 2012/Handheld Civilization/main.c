#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>


void title();
void tutorial();


void upkeep();
void data();
void harassment();
void end();


void commands();

void explore();
void larva();
void nothing();

void fish();
void macrophyte();

void research();
//void stagBeetle();

int day = 1;

int win = 0;

int random;

int rest = 0;

float chitin = 0;
int food = 10;
float inhabitants = 8;
float strenght = 8;
float buffs = 0;

int main()
{
    srand(time(NULL));
    system("cls");
    title();
    Sleep(444);
    tutorial();
    Sleep(444);

    while(1) /*game loop*/
    {
        if(win != 0)
        {
            return 0;
        }

        if(day != 1)
        upkeep();

        if(inhabitants<=0)
        {
            break;
        }

        if(day > 4)
        harassment();

        if(win != 0)
        {
            return 0;
        }

        if(inhabitants<=0)
        {
            break;
        }

        data();
        commands();

        if(inhabitants<=0)
        {
            break;
        }
    }

    system("cls");
    printf("\n\n\n All your inhabitants died!\n\n\n\n\n");
    return 0;
}

void title()
{
    printf("\n \n \n Welcome to the amazing...\n");
    printf("  _   _      _      _      _    _____    _   _    ___    _      ____\n");
    printf(" | | | |    / \\    | |\\\\  | |  |  _  \\  | | | |  |___|  | |    |  _  \\\n");
    printf(" |  =  |   / = \\   | | \\\\ | |  | |_| |  |  =  |  |__|   | |_   | |_| |\n");
    printf(" |_| |_|  /_/ \\_\\  |_|  \\\\|_|  |_____/  |_| |_|  |___|  |___|  |_____/\n");
    printf("\n         CIVILIZATION!\n\n");

    printf("    You have been assigned as the commander of a tiny men\n");
    printf("  civilization located deep in a rain forest and haunted\n");
    printf("  by GIANT INSECTS!\n");
    printf("    Your mission is to guide this little citizens trough\n");
    printf("  days and prepair them for slaying the mythological STAG\n");
    printf("  BEETLE, that has been harassing their village since the\n");
    printf("  beginning of time...\n");


    printf("\n   ---- Press enter to continue ----\n");

    char n;
    scanf("%c",&n);

    system("cls");
}

void tutorial()
{
    printf("\n\n\n  A quick tutorial...\n\n");

    printf(" INHABITANTS: measures the size of you civilization.\n");
    printf(" Ordering them to explore may cause some deaths and, each day,\n");
    printf(" they need to eat after perfoming the designed task, otherwise they die...\n");
    printf(" (note that ordering them to explore increases food consumption by 50%%)\n\n");

    printf(" FOOD: are obtained primarly from fishing nearby lakes and killing insects.\n");
    printf(" As you discover new tecnologies, more reliable methods of obtaining\n");
    printf(" food will be available.\n\n");

    printf(" CHITIN: mainly used in armour and weapon making.\n");
    printf(" The more chitin your civilization has, the deadlier it gets.\n\n");

    printf("\n   ---- Press enter to continue ----\n \n \n \n \n \n");

    char n;
    scanf("%c",&n);

    system("cls");
}



void upkeep()
{
    if(rest == 0)
    {
        food -= inhabitants;
    }
    else
    {
        food -= inhabitants/2;
        rest = 1;
    }

    if(food<0)
    {
        printf("\n\n\n  %d inhabitants starved to death...",(0 - food));
        Sleep(4000);

        inhabitants += food;
        food = 0;

        system("cls");
    }

    if(inhabitants<=1)
    {
        return;
    }

    int newInh = (rand()%((int)inhabitants/2));
    inhabitants += newInh;

    if(newInh != 0)
    {
        system("cls");
        printf("\n\n\n  You have %d new inhabitants at adult age!",newInh);
        Sleep(4000);
        system("cls");
    }

    if((chitin/4)>=inhabitants)
    {
        strenght = 3*inhabitants + buffs;
    }

    else
    {
        strenght = inhabitants + chitin/2 + buffs;
    }

    return;
}

void data()
{
    printf("\n\n\n  Today is day: %d\n\n", day++);
    Sleep(888);
    printf("  Number of inhabitants in your civilization: %.0f\n\n", inhabitants);
    Sleep(444);
    printf("  Available food: %d\n", food);
    Sleep(444);
    printf("  Available chitin: %.0f\n", chitin);
    Sleep(444);
    printf("  Civilization strenght: %.2f\n\n",strenght);
    Sleep(444);

    return;
}

void harassment()
{
    random = rand()%100;

    if(random < 13)
    {
        system("cls");

        printf("\n\n\n   Your village is being looted by the mythological STAG BEETLE!\n");
        Sleep(1300);
        printf("\n  Your inhabitants beging fighting");
        printf(".");
        Sleep(888);
        printf(".");
        Sleep(888);
        printf(".");
        Sleep(2200);

        if(strenght>444)
        {
            system("cls");

            printf("\n\n\n   Your inhabitants managed to slay the mythological STAG BEETLE!\n");
            Sleep(888);
            printf("\n  Your civilization finnaly got rid of its curse,\n");
            printf(" and all thanks to YOU...\n\n\n\n\n\n\n\n\n\n\n\n\n");
            Sleep(888);

            win = 1;

            return;
        }

        else
        {
            system("cls");

            int inhKilled = rand()%((int)inhabitants);
            inhabitants -= inhKilled;

            int foodLost = food/(rand()%4+2);
            food -= foodLost;

            printf("\n\n\n  Your inhabitants could not handle the mythological STAG BEETLE...\n");
            Sleep(888);
            printf("\n - Food stolen: %d",foodLost);
            Sleep(888);
            printf("\n\n - Inhabitants killed: %d",inhKilled);
            Sleep(2200);

            system("cls");
        }
    }
}

void commands()
{
     printf("  Which is the order of the day?\n");
     printf("   (Type 'E' for explore)\n");
     printf("   (Type 'F' for fish)\n");
     printf("   (Type 'R' for research)\n\n");

     printf("          ");

     char c;
     scanf(" %c",&c);

     while ((c != 'E') && (c != 'F') && (c != 'R') && (c != 'e') && (c != 'f') && (c != 'r'))
     {
         printf("Unvalid command!\n");
         scanf(" %c",&c);
     }

     switch(c)
     {
        case 'E':
        case 'e':system("cls");
                 printf("\n\n\n  Your inhabitants start entering the unknown depths of the forest");
                 Sleep(1300);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);

                 explore();

                 break;

        case 'F':
        case 'f':system("cls");

                 rest = 1;

                 printf("\n\n\n  Your inhabitants begin throwing their nets toward the lakes");
                 Sleep(1300);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);

                 fish();

                 break;

        case 'R':
        case 'r':system("cls");

                 rest = 1;

                 printf("\n\n\n  Your inhabitants begin experimenting and studying");
                 printf("\n their tools and techniques");
                 Sleep(1300);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);
                 printf(".");
                 Sleep(888);

                 research();

                 break;
     }

     return;
}


void explore()
{
     random = rand()%100;

     switch(random)
     {
         case 0:
         case 1:
         case 2:
         case 3:
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
         case 13:
         case 14: larva();
                  break;

         case 15:
         case 16:
         case 17:
         case 18:
         case 19:
         case 20:
         case 21:
         case 22: stagBeetle();
                  break;

         default: nothing();
                  break;
     }

     return;
}


void larva()
{
    if(strenght<30)
    {
        int inhFighting = inhabitants;

        int killedInh = rand()%15;
        inhabitants -= killedInh;

        if(inhabitants <= 0)
        {
            int survivors = (rand()%inhFighting) + 1;
            inhabitants = survivors;

            system("cls");

            printf("\n\n\n  Some inhabitants managed to escape from a LARVA ONSLAUGHT!\n\n");
            Sleep(888);
            printf(" - %d were victimized...\n\n",(inhFighting - survivors));
            Sleep(888);
            printf(" - Nothing was looted.\n\n");
            Sleep(1300);
            printf("  ---- Press enter to continue ----\n");

            char n;
            scanf("%c",&n);
            scanf("%c",&n);

            system("cls");

            return;
        }

        system("cls");

        printf("\n\n\n  Your inhabitants slayed a LARVA!\n\n");

        int lootedFood = rand()%8;
        int lootedChitin = rand()%6;

        printf(" - Inhabitants killed: %d\n", killedInh);
        Sleep(888);
        printf(" - Food looted: %d\n", lootedFood);
        Sleep(888);
        printf(" - Chitin looted: %d\n\n",lootedChitin);

        food += lootedFood;
        chitin += lootedChitin;

        Sleep(1300);
        printf("  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");
    }

    else
    {
        system("cls");

        int lostInh = rand()%3;
        inhabitants -= lostInh;

        int lootedFood = rand()%8;
        int lootedChitin = rand()%6;

        printf("\n\n\n  Your civilization DECIMATED a LARVA!\n\n");
        Sleep(888);
        printf("  %d inhabitants got lost in the forest\n\n",lostInh);
        Sleep(1300);
        printf("  ---- Press enter to continue ----\n");

        food += lootedFood;
        chitin += lootedChitin;

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");
    }

    return;
}

void stagBeetle()
{
    system("cls");

    printf("\n\n\n  Your inhabitants were sighted by a mythological STAG BEETLE");
    Sleep(888);
    printf(".");
    Sleep(888);
    printf(".");
    Sleep(888);
    printf(".");
    Sleep(1300);

    if(strenght < 488)
    {
        int inhFighting = inhabitants;

        int killedInh = rand()%(inhFighting/2);
        inhabitants -= killedInh;

        system("cls");

        printf("\n\n\n  Some inhabitants managed to escape from the \n mythological STAG BEETLE onslaught!\n\n");
        Sleep(888);
        printf(" - %d were victimized...\n\n",killedInh);
        Sleep(888);
        printf(" - Nothing was looted.\n\n");
        Sleep(1300);
        printf("  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");

        return;
    }

    system("cls");

    printf("\n\n\n   Your inhabitants managed to slay the mythological STAG BEETLE!\n");
    Sleep(888);
    printf("\n  Your civilization finnaly got rid of its curse,\n");
    printf(" and all thanks to YOU...\n\n\n\n\n\n\n\n\n\n\n\n\n");
    Sleep(888);

    win = 1;

    return;
}

void nothing()
{
    system("cls");

    printf("\n\n\n  Nothing interesting was found...\n\n");
    Sleep(1300);
    printf("  ---- Press enter to continue ----\n");

    char n;
    scanf("%c",&n);
    scanf("%c",&n);

    system("cls");

    return;
}


void fish()
{
    random = rand()%20;

    switch(random)
    {
         default: macrophyte();
                  break;
    }

     return;
}


void macrophyte()
{
    if((day%60) < 8)
    {
        system("cls");

        int foodGath = (rand()%((int)inhabitants)) + inhabitants;

        printf("\n\n\n  New moon!\n\n");
        Sleep(888);
        printf("  Your inhabitants managed to gather e great amount\n");
        printf(" of macrophyte due to the moon phase!\n");
        Sleep(888);
        printf("\n - Food looted: %d\n\n",foodGath);
        Sleep(1300);
        printf("  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");

        food += foodGath;
    }

    else if ((day%13) == 0)
    {
        system("cls");

        printf("\n\n\n  Bad day for fishing...\n");
        Sleep(888);
        printf("\n - No food looted");
        Sleep(1300);
        printf("\n  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");
    }

    else
    {
        system("cls");

        int foodGath = rand()%((int)inhabitants) + inhabitants/2;

        printf("\n\n\n  Your inhabitants managed to gather some macrophyte.\n");
        Sleep(888);
        printf("\n - Food looted: %d",foodGath);
        Sleep(1300);
        printf("\n  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");

        food += foodGath;

    }

    return;
}


void research()
{
    random = rand()%100;

    if(random < 20)
    {
        system("cls");

        int combatTec = (rand()%2) + 1;
        buffs += combatTec;

        printf("\n\n\n  Your inhabitants improved their combat techniques!\n");
        Sleep(888);
        printf("\n - (+%d) strenght bonus!\n\n",combatTec);
        Sleep(1300);
        printf("  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");
    }

    else
    {
        system("cls");

        printf("\n\n\n  Despite your inhabitants effort, no new\n");
        printf(" tecnologies were discovered.\n");
        Sleep(1300);
        printf("\n  ---- Press enter to continue ----\n");

        char n;
        scanf("%c",&n);
        scanf("%c",&n);

        system("cls");
    }

    return;
}




//do continue function
//implement boss & new encounters
//implement diseases
