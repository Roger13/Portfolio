function Background(str){
  //Horizontal displacement
  this.dX = 5;
  
  this.i = Math.floor((10*Math.random()))%2 + 1;
   this.bgImg = rsc.img[rsc.imgName[str+this.i]];

  //Horizontal coordinate
  this.x = this.bgImg.naturalWidth;
  this.str = str;
}

Background.prototype.draw = function(){
  
  //Update coordinate
  this.x -= this.dX;
  
  if(this.x <= -this.bgImg.naturalWidth){
    this.x = this.bgImg.naturalWidth + (this.x + this.bgImg.naturalWidth);
    
    //Change the image
    this.i = Math.floor((10*Math.random()))%2 + 1;
    this.bgImg = rsc.img[rsc.imgName[this.str+this.i]];
  }
  
  //Draw
  ctx.drawImage(this.bgImg, this.x, 0);
}


function StaticBG(str){

   this.sImg = rsc.img[rsc.imgName[str]];
}

StaticBG.prototype.draw = function(){
  ctx.drawImage(this.sImg, 0, 0);
}

function FrontBG(i){
  this.fImg = rsc.img[rsc.imgName["water"+i]];
  this.x = this.fImg.naturalWidth;
  this.dX = 0;
}

FrontBG.prototype.draw = function(){
    
  //Update coordinate
  this.x -= this.dX;
  
  if(this.x <= -this.fImg.naturalWidth){
    this.x = this.fImg.naturalWidth + (this.x + this.fImg.naturalWidth);
  }
  
  //Draw
  ctx.drawImage(this.fImg, this.x, 0);
}