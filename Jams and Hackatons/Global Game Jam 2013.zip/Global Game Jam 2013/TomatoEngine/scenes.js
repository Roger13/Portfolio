function changeScene(n)
{
  switch(n)
  {
    case 0: // Intro
      glb.update = introUpdate;
      glb.draw = introDraw;
      break;
    case 1: // Battle
      glb.update = battleUpdate;
      glb.draw = battleDraw;
      break;
    case 2:
      
      
      break;
    default:
      glb.update = voidf;
      glb.draw = voidf;
  }
}

function introUpdate()
{
  if(glb.key.on == true)
  {
    if(glb.key.code == 32 ) 
    {
      changeScene(1);
    }
  }
}

function introDraw()
{

  glb.ctx.fillStyle = 'green';
  glb.ctx.fillText('Welcome to Tomatoes Console v0.03', 210, 75);
  
  glb.ctx.font = glb.smallfont;
  
  glb.ctx.fillStyle = 'white';
  glb.ctx.fillText('Select a test battle:', 0, 150);

  glb.ctx.fillStyle = 'red';
  glb.ctx.fillText('BATTLE_001',0 ,175);
  
  glb.ctx.fillStyle = 'white';
  glb.ctx.fillText(' selected! ', 100 , 175 );
  
  glb.ctx.font = glb.bigfont;
  glb.ctx.fillText('Press space to begin!', 270 , 575);

}

function battleUpdate()
{


}

function battleDraw()
{


}