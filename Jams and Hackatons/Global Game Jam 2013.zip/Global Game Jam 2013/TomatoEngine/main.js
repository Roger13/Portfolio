// Main

var glb = {};
window.onload = function () 
{
  initialize();
  setInterval(frame, glb.dt);
}

function frame()
{
  var dt = (new Date()).getTime();

  update();
  draw();

  
  glb.dt = (new Date()).getTime() - dt;
  glb.dt = (glb.dt < 16.66) ? 16.66 : glb.dt;
  glb.fps = parseInt(1000/glb.dt);

}

function initialize()
{
  glb.state = 0;
  glb.canvas = document.getElementById('consol');
  glb.canvas.addEventListener('keydown', keyDown, false);
  glb.canvas.addEventListener('mousedown', mouseDown, false);
  glb.canvas.focus();
  glb.ctx = glb.canvas.getContext('2d');
  glb.bigfont = 'bold 22px Arial';
  glb.smallfont = '16px Arial';
  glb.ctx.font = glb.bigfont;
  glb.dt = 33;
  glb.fps = 30;
  glb.update = voidf;
  glb.draw = voidf;
  glb.key = {};
  glb.mouse = {};
  glb.key.code = 0;
  glb.key.on = false;
  glb.mouse.on = false;
  glb.mouse.X = 0;
  glb.mouse.Y = 0;
  glb.key.down = false;
  glb.mouse.down = false;
  
  changeScene(0);
}

function update()
{
  input();
  glb.update();
}

function draw()
{
  glb.ctx.fillStyle = '#0A0A0A';
  glb.ctx.fillRect(0, 0, glb.canvas.width, glb.canvas.height);
  
  glb.draw();
  
  glb.ctx.fillStyle = 'yellow';
  glb.ctx.fillText('FPS: ' + glb.fps, 2, 20);
}

function input()
{
  glb.key.on = glb.key.down;
  glb.mouse.on =  glb.mouse.down;


  glb.key.down = false;
  glb.mouse.down = false;
}

function keyDown(e) 
{
  glb.key.code = e.keyCode;
  glb.key.down = true;
}

function mouseDown(e)
{
  glb.mouse.X = e.clientX;
  glb.mouse.Y = e.clientY;
  glb.mouse.down = true;
}

function voidf() {}