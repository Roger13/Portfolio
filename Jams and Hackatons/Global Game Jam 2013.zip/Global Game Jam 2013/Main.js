var adBar;
var stBar;
var staticBG;
var menuBG;
var frontBG1;
var frontBG2;
var aquaBG1;
var aquaBG2;
var aquaBG3;
var aquaBG4;
var back1;
var back2;
var back3;
var back4;
var nuvem1;
var nuvem2;
var bGround1;
var bGround2;
var obstacle1;
var obstacle2;
var gancho1;
var gancho2;
var sback1;
var sback2;
var heart;
var player;
var toogle;
var g;
var c;
var ctx;
var rsc;
var amg;
var loopInterval;
var music;


function menuLoop() {
  ctx.clearRect(0,0,800,600);
  sback1.draw();
  sback2.draw();
  menuBG.draw();
  aquaBG1.draw();
  aquaBG2.draw();
  aquaBG3.draw();
  aquaBG4.draw();
  nuvem1.draw();
  nuvem2.draw();
  aquaBG1.dX = 3;
  aquaBG2.dX = 3;
  aquaBG3.dX = 2;
  aquaBG4.dX = 2;
  nuvem1.dX = 1;
  nuvem2.dX = 1;
  sback1.dX = 0;
  sback2.dX = 0;
  
  toogle += 10;
  
  if( toogle > 80 && toogle < 160) {
    pressStart();
  } else if( toogle > 160) {
    toogle = 0;
  }

}

function pressStart() {
  ctx.font ="normal 32px Impact";
  ctx.fillText("Click to start!", 310, 190);
}

function menuStart(){
  loopInterval = clearInterval(loopInterval);
  c.removeEventListener("mousedown",menuStart,false);
  c.addEventListener("mousedown",increaseAdrenaline,false);
  loopInterval = setInterval("mainLoop()",16.6);
  setInterval("decreaseAdrenaline()",100);
  
  aquaBG1.x = 0;
  aquaBG2.x = aquaBG2.fImg.naturalWidth;
  aquaBG3.x = 0;
  aquaBG4.x = aquaBG2.fImg.naturalWidth;
  
  nuvem1.x = 0;
  nuvem2.x = 800;
  
  sback1.x = 0;
  sback2.x = 800;
}

function mainLoop(){
  //Clear all
  ctx.clearRect(0,0,800,600);
  amg.sound[amg.soundName["siren"]].pause();
  
  obstacle1.dX = 3 + 3*adBar.fillPercent;
  obstacle2.dX = 3 + 3*adBar.fillPercent;
  aquaBG1.dX = 5 + 3*adBar.fillPercent;
  aquaBG2.dX = 5 + 3*adBar.fillPercent;
  aquaBG3.dX = 3 + 3*adBar.fillPercent;
  aquaBG4.dX = 3 + 3*adBar.fillPercent;
  back1.dX = 1 + 3*adBar.fillPercent;
  back2.dX = 1 + 3*adBar.fillPercent;
  bGround1.dX = 3 + 3*adBar.fillPercent;
  bGround2.dX = 3 + 3*adBar.fillPercent;
  nuvem1.dX = 1 + 3*adBar.fillPercent;
  nuvem2.dX = 1 + 3*adBar.fillPercent;
  gancho1.dX = 3 + 3*adBar.fillPercent;
  gancho2.dX = 3 + 3*adBar.fillPercent;
  sback1.dX = 1;
  sback2.dX = 1;
  
  //Draw 
  staticBG.draw();
  sback1.draw();
  sback2.draw();
  nuvem1.draw();
  nuvem2.draw();
  back1.draw();
  back2.draw();
  bGround1.draw();
  bGround2.draw();
  aquaBG1.draw();
  aquaBG2.draw();
  aquaBG3.draw();
  aquaBG4.draw();
  obstacle1.draw();
  obstacle2.draw();
  gancho1.draw();
  gancho2.draw();
  adBar.draw();
  stBar.draw();
  heart.draw();
  player.draw();
  
  if((player.jumping == false)&&(amg.sound[amg.soundName["correndo"]].paused)){
  amg.sound[amg.soundName["correndo"]].play();
  }
  
  if((stBar.fillPercent <= 0.4) && (stBar.fillPercent >= 0.05)){
  ctx.font ="normal 60px Impact";
  ctx.fillText("Slow down!", 80, 160);
  }
  
  else if((adBar.fillPercent <= 0.25) && (adBar.fillPercent >= 0.05)){
	ctx.font ="normal 60px Impact";
	ctx.fillText("Keep pumping!", 80, 160);
	heart.pumpDraw();
  }
  
  if(stBar.fillPercent == 0){
    invokeDeath(0);
  }
  
  if(adBar.fillPercent == 0){
    invokeDeath(1);
  }
}

function invokeDeath(n) {
  loopInterval = clearInterval(loopInterval);
  
  obstacle1.dX = 0;
  obstacle2.dX = 0;
  gancho1.dX = 0;
  gancho2.dX = 0;
  bGround1.dX = 0;
  bGround2.dX = 0;
  back1.dX = 0;
  back2.dX = 0;
  aquaBG1.dX = 3;
  aquaBG2.dX = 3;
  aquaBG3.dX = 2;
  aquaBG4.dX = 2;
  nuvem1.dX = 1;
  nuvem2.dX = 1;
  sback1.dX = 0;
  sback2.dX = 0;
  player.i = 0;
  
  g = n;
  
  music.pause();
  amg.sound[amg.soundName["correndo"]].pause();
  amg.sound[amg.soundName["siren"]].pause();
  amg.sound[amg.soundName["yay"]].pause();   
  
  c.removeEventListener("mousedown",increaseAdrenaline,false);
  
  setTimeout("deathWait()", 1000);
  
  setInterval("deathLoop()",16.6);
}

function deathWait() {
  c.addEventListener("mousedown",deathClick,false);
}

function deathLoop() {
  
  ctx.fillStyle = stBar.grd;	
  
  ctx.clearRect(0,0,800,600);
  staticBG.draw();
  sback1.draw();
  sback2.draw();
  nuvem1.draw();
  nuvem2.draw();
  back1.draw();
  back2.draw();
  bGround1.draw();
  bGround2.draw();
  aquaBG1.draw();
  aquaBG2.draw();
  aquaBG3.draw();
  aquaBG4.draw();
  obstacle1.draw();
  obstacle2.draw();
  gancho1.draw();
  gancho2.draw();
  heart.deathDraw();
  player.deathDraw();
  
  if(g == 0){
  ctx.font ="normal 30px Impact";
  ctx.fillText("You ran for " + Math.floor(heart.score) + " meters!", 240, 255);
  ctx.font ="normal 80px Impact";
  ctx.fillText("No stamina!",220,225);
  }
  
  if(g == 1){
    ctx.font ="normal 30px Impact";
    ctx.fillText("You ran for " + Math.floor(heart.score) + " meters!", 240, 255);
    ctx.font ="normal 80px Impact";
    ctx.fillText("No adrenaline!",220,225);
  }
    ctx.font ="normal 40px Impact";
	ctx.fillStyle = "#DD4444"
    ctx.fillText("Click to try again!", 230, 325);
  
}

function deathClick(){ 
  document.location.reload(true)
}

function loadImage(str) {
  rsc.img[rsc.imgCount] = new Image();
  rsc.img[rsc.imgCount].src = 'Images/' + str + '.png';
  rsc.img[rsc.imgCount].onload = completeImage();
  rsc.imgName[str] = rsc.imgCount;
  rsc.imgCount++;
}

function completeImage(){
  rsc.imgCountComplete++;
}

function loadAllImages() {
  rsc = {};
  rsc.img = [];
  rsc.imgName = [];
  rsc.imgCount = 0;
  rsc.imgCountComplete = 0;
  
  loadImage("test");
  loadImage("runner");
  loadImage("death");
  loadImage("jump");
  loadImage("heart");
  loadImage("button");  
  loadImage("static");
  loadImage("barris");
  
    
  var i;
  
  for(i = 1; i < 3; ++i){
    loadImage("layout"+i);
    loadImage("water"+i);
    loadImage("back"+i);
    loadImage("nuvem" + i);
    loadImage("gancho" + i);
    loadImage("sback" + i);
  }
  
  for(i = 1; i < 5; ++i){
    loadImage("box_"+i);
  }
  
  var aux = 0;
  while(aux < rsc.imgCount) {
    if(typeof rsc.img[aux].naturalWidth != "undefined"){
      if (typeof rsc.img[aux].naturalWidth == 0 ) {    
        aux = 0;
        continue;
      }
    }
    aux++;
}
  
  return true;
}

function loadAllSounds() {
  amg = {};
  amg.sound = [];
  amg.soundName = [];
  amg.soundCount = 0;
  
  loadSound("correndo");
  loadSound("siren");
  loadSound("yay");
  loadSound("caixas");
}

function loadSound(str) {
  amg.sound[amg.soundCount] = new Audio();
  amg.sound[amg.soundCount].src = 'Sounds/' + str + '.mp3';
  amg.soundName[str] = amg.soundCount;
  amg.soundCount++;
}

function init(){
  //Get the canvas and the context
  c = document.getElementById("myCanvas");
  ctx = c.getContext("2d");

  //Set the timing events and event handlers
  c.focus();
  
  ctx.font = "normal 80px Impact"
  ctx.fillStyle = "#DD4444";
  ctx.fillText("Loading...",225,225);
  
  if(!loadAllImages())
    console.error("IMAGE ERROR");
    
  loadAllSounds();
  amg.sound[amg.soundName["siren"]].volume = 0.3;		

  music = document.getElementById("musica");  
  music.loop = true;
  
  g = 0.5;
  player = new Runner();
  heart = new Heart();
  obstacle1 = new Obstacle();
  obstacle2 = new Obstacle();
  bGround1 = new Background("layout");
  bGround2 = new Background("layout");
  staticBG = new StaticBG("static");
  menuBG = new StaticBG("test");
  aquaBG1 = new FrontBG(1);
  aquaBG2 = new FrontBG(1);
  aquaBG3 = new FrontBG(2);
  aquaBG4 = new FrontBG(2);
  back1 =  new Background("back");
  back2 =  new Background("back");
  nuvem1= new Background("nuvem");
  nuvem2= new Background("nuvem");
  gancho1 = new Background("gancho");
  gancho2 = new Background("gancho");
  sback1 = new Background("sback");
  sback2 = new Background("sback");
  stBar = new Indicator(51,10,"#6195B3","#30409A");
  stBar.stroke = false;
  adBar = new Indicator(16,10,"#552222","#FF4444");
  
  while(rsc.imgCount > rsc.imgCountComplete){
  
  }
  obstacle2.x = obstacle1.x + 800;
  bGround1.x = 0;
  bGround2.x = 800;
  aquaBG1.x = 0;
  aquaBG2.x = 800;
  aquaBG3.x = 0;
  aquaBG4.x = 800;
  back1.x = 0;
  back2.x = 800;
  nuvem1.x = 0;
  nuvem2.x = 800;
  gancho1.x = 0;
  gancho2.x = 800;
  sback1.x = 0;
  sback2.x = 800;
  toogle = 0;
  
  loopInterval = setInterval("menuLoop()",16.6);
  c.addEventListener("mousedown",menuStart,false);
}