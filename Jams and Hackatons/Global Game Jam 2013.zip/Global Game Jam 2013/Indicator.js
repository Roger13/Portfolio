function Indicator(x,y,stop,stop2){
	this.x = x;
	this.y = y;
	this.fillPercent = 1;
	this.stop = stop;
	this.stop2 = stop2;
	this.grd = ctx.createLinearGradient(this.x, this.y, 0, this.y+150 );
	this.grd.addColorStop(0, this.stop);
	this.grd.addColorStop(1, this.stop2);
	this.stroke = true;
}

Indicator.prototype.draw = function(){
	ctx.strokeStyle = "#CEDAED";
	ctx.lineWidth = 2;
	ctx.fillStyle = this.grd;
	height = 150*this.fillPercent;
	
	ctx.fillRect(this.x,150 + this.y - height,20,height);
	if(this.stroke){
		ctx.strokeRect(this.x,this.y,20,150);
		ctx.strokeRect(this.x,this.y,20,120);
		ctx.strokeRect(this.x,this.y,20,90);
		ctx.strokeRect(this.x,this.y,20,60);
		ctx.strokeRect(this.x,this.y,20,30);
	}
}


function increaseAdrenaline(e){
  
  var adr =  0.125*(1 - adBar.fillPercent);
  adr = ( adr < 0.1 ) ? 0.1 : adr;
  
  adBar.fillPercent += adr;
  
  //Fixing the indicators bounds
  if(adBar.fillPercent > 1){
    adBar.fillPercent = 1;
  }
  

}

function decreaseAdrenaline(){

  var adr =  0.05 *(adBar.fillPercent);
  adr = ( adr < 0.01 ) ? 0.01 : adr;

  var aux = (1-adr)*(0.0225 - adr);
  
  if(player.jumping)
    aux = 0;
  
  adBar.fillPercent -=  adr;
  stBar.fillPercent +=  aux + (1 - stBar.fillPercent) * 0.005 ;
  
  //Fixing the indicators bounds
  if(adBar.fillPercent < 0){
    adBar.fillPercent = 0;
  }
  
  if(stBar.fillPercent > 1){
    stBar.fillPercent = 1;
  }
  
  if(stBar.fillPercent < 0){
    stBar.fillPercent = 0;
  }
}