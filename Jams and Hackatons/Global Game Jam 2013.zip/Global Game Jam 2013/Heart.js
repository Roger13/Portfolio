function Heart() {
  this.br = 50;
  this.i = 0;
  this.h = 0;
  this.font = 'normal 22px Impact';
  this.playerImg = rsc.img[rsc.imgName["heart"]];
  this.pumpImg = rsc.img[rsc.imgName["button"]];
  this.score = 0;
}

Heart.prototype.pumpDraw = function(){
  ctx.drawImage(this.pumpImg, (this.i%2)*194, 0, 194, 170, 610, 300, 194, 170);
  
  if((amg.sound[amg.soundName["siren"]].paused)&&(bGround1.dX != 0)){
	amg.sound[amg.soundName["siren"]].play();	
  }
}

Heart.prototype.deathDraw = function() {
  ctx.drawImage(this.playerImg, 192 + this.i*48, 0, 48, 48, 115, 5, 72, 72);

  ctx.font = this.font;
  ctx.fillText( Math.floor(this.br), 140, 50);
  ctx.fillText("Meters: " + Math.floor(this.score), 100, 100);
  
  this.h += 10;
  if(this.h > player.j){
    this.h = 0;
    this.i = (this.i + 1)%2;
  } 


}


Heart.prototype.draw = function() {
  ctx.drawImage(this.playerImg, this.i*48, 0, 48, 48, 115, 5, 72, 72);

  ctx.font = this.font;
  ctx.fillText( Math.floor(this.br), 140, 50);
  ctx.fillText("Meters: " + Math.floor(this.score), 100, 100);
  
  this.h += 10;
  if(this.h > player.j){
    this.h = 0;
    this.i = (this.i + 1)%4;
  } 
  
  this.br = 50 * (1 + adBar.fillPercent*0.99);
  
  this.score += (1 + adBar.fillPercent*9)/32;
}