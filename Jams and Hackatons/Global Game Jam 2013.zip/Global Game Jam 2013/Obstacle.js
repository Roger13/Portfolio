function Obstacle(){
  //Horizontal coordinate (set standart value)
  this.x = 1000;
  this.y = 140;
  this.i = 0;
  this.j = 19;
  this.h = 10;
  
  this.dX;
  this.broken = false;
  this.r = Math.floor((10*Math.random()))%4 + 1;
  this.objectImg = rsc.img[rsc.imgName["box_" + this.r]];
  this.fail = false;
    

  this.level = 0.2 * (this.r );
  this.vel = 10 + this.level * 7;
    
    this.gap = player.x - 90 + 20*this.level; 
}

Obstacle.prototype.draw = function(){

  this.x -= this.dX;
    
  if(this.x <= -(100 + this.objectImg.naturalWidth/11)){
    this.fail = false;
    this.broken = false;
    this.i = 0;
    this.x = 800;
    this.r = Math.floor((10*Math.random()))%4 + 1;
    if(this.r == 2){
       if(Math.floor((10*Math.random()))%2 == 0)
         this.objectImg = rsc.img[rsc.imgName["box_2"]];
       else 
        this.objectImg = rsc.img[rsc.imgName["barris"]];
    } else 
      this.objectImg = rsc.img[rsc.imgName["box_" + this.r]];
    this.level = 0.2 * (this.r );
    this.vel = 10 + this.level * 7;
    this.gap = player.x - 90 + 20*this.level; 
  } else if( this.fail && !this.broken){
    if( this.x + 180 < player.x ){
      this.broken = true;
      stBar.fillPercent -= 0.7 + this.level;
      stBar.fillPercent = (stBar.fillPercent > 0) ? stBar.fillPercent : 0;
	  amg.sound[amg.soundName["caixas"]].play();
    }
  } else if((this.x + 135 > player.x ) && (!player.jumping) ){
    if (this.x < this.gap) {
      if(adBar.fillPercent > this.level) {
        player.jumping = true;
        player.vel = this.vel;
	      stBar.fillPercent -= 0.1;
        stBar.fillPercent = (stBar.fillPercent < 0) ? 0.01 : stBar.fillPercent;
	    amg.sound[amg.soundName["correndo"]].pause();
      } else 
      this.fail = true;
    } else if (adBar.fillPercent < this.level && this.x < this.gap + 350) 
      heart.pumpDraw();
  }

    
  if(this.broken){
	
     this.h += 10;
     if(this.h>this.j){
       this.h = 0;
       this.i = (this.i < 10) ? this.i + 1 : 10;
    }    
  }
  
  ctx.drawImage(this.objectImg, this.i*370, 0, 370, 250, this.x, this.y, 370, 250);
  
  
  if(player.jumping && this.level > 0.4){
    ctx.font ="normal 80px Impact";
	ctx.fillText("Awesome!", 340, 90);
	
	amg.sound[amg.soundName["yay"]].play();
	amg.sound[amg.soundName["yay"]].currentTime = 0;
  }
  if(this.fail){
	ctx.font ="normal 65px Impact";
   ctx.fillText("Go faster next time!", 220, 90);
  }
}