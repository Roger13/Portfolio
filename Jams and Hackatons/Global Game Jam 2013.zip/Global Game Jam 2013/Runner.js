function Runner(){
  //X crop coordinate
  this.i = 0;
  //Fps limiter
  this.j = 32;
  //Time counter
  this.h = 0;
  
  //Vertocal coordenate
  this.y = 290;
  this.floor = 290;
  //Vertical displacement
  this.vel = 0;
  
  this.x = 100;
  this.jumping = false;
  
  //Player image
  this.playerImg = rsc.img[rsc.imgName["runner"]];
  //Player jumping image REFERENCIA PRA IMAGEM DO PULO
  this.playerJumpImg = rsc.img[rsc.imgName["jump"]];
  this.playerDeathImg = rsc.img[rsc.imgName["death"]];
}

Runner.prototype.draw = function(fillPercent){
  //Update coordinates

  
  if (this.y > this.floor) {
    this.vel = 0;
    this.jumping = false;
    this.y = this.floor;
  }
  else{
    this.y -= this.vel;
    this.vel -= g;
    }
    
  if(this.jumping){
    ctx.drawImage(this.playerJumpImg, this.i*62, 0, 62, 99, this.x, this.y, 62, 99);
    
    //Increase counter
    this.h += 10;
    //Set the limiter
    this.j = 64 - (10 * adBar.fillPercent);
    //Reset/change the image crop
    if(this.h>this.j){
      this.h = 0;
      this.i = (this.i + 1)%8;
    }    
  }
  
  //If running
  else{
    ctx.drawImage(this.playerImg, this.i*62, 0, 62, 99, 100, this.y, 62, 99);
  
    //Increase counter
    this.h += 10;
    //Set the limiter
    this.j = 40 - (16 * adBar.fillPercent);
    //Reset/change the image crop
    if(this.h>this.j){
      this.h = 0;
      this.i = (this.i + 1)%8;
    }
  }
  


}


Runner.prototype.deathDraw = function() {

    ctx.drawImage(this.playerDeathImg, this.i*124, 0, 124, 99, 68, this.y, 124, 99);
  
    //Increase counter
    this.h += 10;
    //Set the limiter
    this.j = 120;
    //Reset/change the image crop
    if(this.h>this.j){
      this.h = 0;
      this.i = (this.i <  7) ? this.i + 1 : 7;
    }
}