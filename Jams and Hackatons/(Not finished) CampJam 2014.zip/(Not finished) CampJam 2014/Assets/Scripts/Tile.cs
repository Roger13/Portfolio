﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Tile : MonoBehaviour
{
	public int range;
	public int ID;
	public int zoneID;
	public int color;
	public bool free;
	public GameObject hrt, spd, clb, dmd, suit;
	
	public void Suit()
	{
		Quaternion rot = Quaternion.identity;
		switch(color)
		{	
			case 0:
				suit = (GameObject)Object.Instantiate(clb, transform.position, rot);
				(suit).transform.parent = transform;
				break;
			case 1:
				suit = (GameObject)Object.Instantiate(hrt, transform.position, rot);
				(suit).transform.parent = transform;
				break;
			case 2:
				suit = (GameObject)Object.Instantiate(spd, transform.position, rot);
				(suit).transform.parent = transform;
				break;
			default:
				suit = (GameObject)Object.Instantiate(dmd, transform.position, rot);
				(suit).transform.parent = transform;
				break;
			}
	}
	
	public void Fade()
	{
		SpriteRenderer spt = ((SpriteRenderer)renderer);
		spt.color = new Color(spt.color.r, spt.color.g, spt.color.b, 0.15f);
		spt = (SpriteRenderer)suit.renderer;
		spt.color = new Color(spt.color.r, spt.color.g, spt.color.b, 0.15f);
		
	}
	
	public void Appear()
	{
		SpriteRenderer spt = ((SpriteRenderer)renderer);
		spt.color = new Color(spt.color.r, spt.color.g, spt.color.b, 0.55f);
		spt = (SpriteRenderer)suit.renderer;
		spt.color = new Color(spt.color.r, spt.color.g, spt.color.b, 0.55f);
	}
	
	
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
}
