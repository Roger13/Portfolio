﻿using UnityEngine;
using System.Collections;

public class RhythmIndicator : MonoBehaviour {

	public Object rightSymbol;
	public Object wrongSymbol;

	private float initialPos;
	private bool movendoDireita;

	// Use this for initialization
	void Start () {
		movendoDireita = false;

		initialPos = 0.16f;
		this.GetComponent<HudSprite> ().xOffset = initialPos;
	}
	
	// Update is called once per frame
	void LateUpdate () {

		if (movendoDireita) {
			this.GetComponent<HudSprite> ().xOffset = initialPos - 0.08f * Mathf.Sin (Mathf.PI * (InputManager.audioDelay + InputManager.time) / InputManager.tick);
			if(InputManager.time >= InputManager.tick){
				movendoDireita = false;
			}
		}
		else {
			this.GetComponent<HudSprite> ().xOffset = initialPos + 0.08f * Mathf.Sin (Mathf.PI * (InputManager.audioDelay + InputManager.time) / InputManager.tick);
			if(InputManager.time >= InputManager.tick){
				movendoDireita = true;
			}
		}
	}

	public void InstantiateCorrect () {
		GameObject correctSymbol = (GameObject)Instantiate (this.rightSymbol);
		correctSymbol.transform.position = this.transform.position;
		correctSymbol.transform.localScale = this.transform.localScale/2;
		Destroy (correctSymbol, 0.4f);
	}

	public void InstantiateIncorrect () {
		GameObject incorrectSymbol = (GameObject)Instantiate (this.wrongSymbol);
		incorrectSymbol.transform.position = this.transform.position;
		incorrectSymbol.transform.localScale = this.transform.localScale/2;
		Destroy (incorrectSymbol, 0.4f);
	}
}
