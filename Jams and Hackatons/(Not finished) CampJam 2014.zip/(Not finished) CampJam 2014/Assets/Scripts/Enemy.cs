﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour {
	public Animator animat;

	int hp = 1;
	int range = 1;


	public Tile target;
	public Tile tile;
	bool moving = false;
	float time;
	float resetTime;
	int death = 0;
	bool attacking = false;
	int attacked = 0;

	void Start ()
	{
		resetTime = InputManager.tick * 5 / 8;
	}

	void Update ()
	{
		if (death != 0)
		{
			if (InputManager.time > InputManager.tick)
			{
				if (death == 1)
					animat.SetTrigger("Death");
				else if (death == 3)
					Object.Destroy(this.gameObject);
				death++;
			}
			return;
		}

		if (moving)
		{
			transform.position = Vector3.Lerp(tile.transform.position, target.transform.position, InputManager.time / InputManager.tick);
			if (InputManager.time > InputManager.tick)
			{
				tile = target;
				target = null;
				moving = false;
			}
		}

		if (attacking)
		{
			if (InputManager.time > InputManager.tick)
			{
				attacked ++;
				if (attacked == 2 && !InputManager.move)
				{
					animat.SetBool("Attack", true);
					StartCoroutine("Reset");
				}
				else if (attacked == 3)
				{
					SFX.singleton.PlaySound(1);
					attacking = false;
				}
			}
		}
	}

	public bool InRange ()
	{
		return (tile.range == range);
	}

	IEnumerator Reset ()
	{
		yield return new WaitForSeconds(resetTime);
		
		animat.SetBool("Movement", false);
		animat.SetBool("Attack", false);
		animat.SetBool("GotHit", false);
	}

	public bool GetHit (int hit)
	{
		hp--;
		if (hp <= 0)
		{
			death = 1;
			return true;
		}
		else
		{
			animat.SetBool("GotHit", true);
			return false;
		}

		StartCoroutine("Reset");
	}

	public void Move ()
	{
		animat.SetBool("Movement", true);
		moving = true;
		
		StartCoroutine("Reset");
	}

	public bool Attack ()
	{
		if (!InRange())
			return false;

		attacked = 0;
		attacking = true;
		return true;
	}
}
