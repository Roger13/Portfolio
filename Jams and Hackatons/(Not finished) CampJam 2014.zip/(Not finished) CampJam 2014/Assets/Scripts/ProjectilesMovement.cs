using UnityEngine;
using System.Collections;

public class ProjectilesMovement : MonoBehaviour {

	public Vector3 start;
	public float x; // destination x
	public float y; // destination y

	private float timeCounter;

	// Use this for initialization
	void Start () {
		timeCounter = 0;

		// Rotates the arrow according to its destination
		if (x >= 0) {
			if( y >= 0) {
				this.transform.Rotate(0,0,57.2957795f * Mathf.Atan2(y,x));
			}
			else{
				this.transform.Rotate(0,0,57.2957795f * Mathf.Atan2(y,x));
			}
		}
		else{
			if( y >= 0) {
				this.transform.Rotate(0,0,57.2957795f * Mathf.Atan2(y,x));		
			}
			else{
				this.transform.Rotate(0,0,57.2957795f * Mathf.Atan2(y,x));
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
		timeCounter += Time.deltaTime;

		this.transform.position = new Vector3 (Mathf.Lerp (start.x, x, timeCounter/InputManager.tick),Mathf.Lerp (start.y, y, timeCounter/InputManager.tick),-2);

		if(timeCounter/InputManager.tick > 1){
			DestroyImmediate(this.gameObject);
		}
	}
}
