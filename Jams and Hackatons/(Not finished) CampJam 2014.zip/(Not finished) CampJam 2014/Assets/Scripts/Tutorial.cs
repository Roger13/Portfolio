﻿using UnityEngine;
using System.Collections;

public class Tutorial : MonoBehaviour {
	
	public int option;
	TextMesh txt;
	
	// Use this for initialization
	void Start () 
	{
		txt = (TextMesh)(gameObject.GetComponentInChildren<TextMesh>());
		option = 0;
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		switch(option)
		{
		case 0:
			txt.text = "Defend your castle against the \n" +
			 	"army of Jokers!\n" +
			 	"You lose if your Castle is \n" +
			 	"destroyed!\n" +
			 	"Click to go to the next page...";
			break;
		case 1:
			txt.text = "Select your weapon in the offbeats! \n" +
				"Choose which colors to attack in \n" +
				 "the main beat!\n" +
				"Click to go to the next page...";
			break;
		case 2:
			txt.text = "You can only hit tiles in the \n" +
				"current zone! \n" +
				"Plan your attacks carefully!\n" +
				"Remember the colors!\n" +
				"Click to go to the next page...";
			break;
		case 3:
			txt.text = "Good luck!\n" +
				"Click again to go back \n" +
				 "to the MainMenu!";
			break;
		default:
			Application.LoadLevel("MainMenu");
			break;
		}
	
	}
	
	void OnMouseDown () 
	{
		option++;
	}
	
}
