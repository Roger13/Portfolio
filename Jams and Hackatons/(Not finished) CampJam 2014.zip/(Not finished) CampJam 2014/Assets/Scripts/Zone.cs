﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class Zone : MonoBehaviour {
	

	public List<List<Tile>> range;
	public List<Tile> hexagons;
	public List<Enemy> dudes, kill;
	public bool big;

	public GameObject enemy;

	public Zone()
	{
		dudes = new List<Enemy>();
		kill = new List<Enemy>();
		hexagons = new List<Tile>();
		range = new List<List<Tile>>();
		range.Insert(0, new List<Tile>());
		range.Insert(1, new List<Tile>());
		range.Insert(2, new List<Tile>());
		range.Insert(3, new List<Tile>());
		range.Insert(4, new List<Tile>());
		
	}
	
	public void Assign(Tile tl)
	{	
		range[tl.range].Add(tl);
		hexagons.Add (tl);
		tl.free = true;
	}
	
	public void Fade()
	{
		int i, j;
		for(i=1; i<5; i++) // Ignore Castle
		{
			for(j=0; j<range[i].Count; j++)
			{
				range[i][j].Fade();
				
			}
		}
	}
	
	public void Appear()
	{
		int i, j;
		for(i=1; i<5; i++) // Ignore Castle
		{
			for(j=0; j<range[i].Count; j++)
			{
				range[i][j].Appear();
			}
		}
		
	}
	
	public void SortTiles()
	{
		int i, j, k;
		for(i=1; i<5; i++) // Ignore Castle
		{
			range[i].Sort((x, y) => x.ID.CompareTo(y.ID));
			k = 0;
			for(j=0; j<range[i].Count; j++)
			{
				range[i][j].zoneID = k;
				k++;
			}
		}	
	}
	
	
	public void ShuffleTiles()
	{
		float f = 1 / hexagons.Count;
		int i, j, k;
		int r, g, b;
		r = 0; g = 0; b = 0; // Red = 0, Blue = 1, Green = 2, Yellow = 3
		Random.seed = (int)System.DateTime.Now.Ticks; // Complete with randoms
		
		int[] c = new int[hexagons.Count];
		for(i=0; i < hexagons.Count; i++)
		{
			float n = Random.value;
			if(n < 0.25f - r * f )
			{
				c[i] = 0;
			}
			else if(n < 0.5f - b * f)
			{
				c[i] = 1;
			}
			else if(n < 0.75f - g * f)
			{
				c[i] = 2;
			}
			else
			{
				c[i] = 3;
			}
		}		
		
		k = 0;
		for(i=1; i<5; i++) // Ignore Castle
		{
			for(j=0; j<range[i].Count; j++)
			{
				SpriteRenderer spt = (SpriteRenderer)(range[i][j].renderer);
				switch(c[k])
				{	
				case 0:
					spt.color = Color.green;
					break;
				case 1:
					spt.color = Color.red;
					break;
				case 2:
					spt.color = Color.blue;
					break;
				default:
					spt.color = Color.yellow;
					break;
				}
				range[i][j].color = c[k];
				range[i][j].Suit();
				k++;
			}
		}
	}
	
	
	public void Move()
	{
		 foreach(Enemy d in dudes)
		 {
		   if( d.InRange() || d.target == null )		
		   	continue;
		   d.Move();
		 }
	}
	
	public List<Vector3> CheckEnemiesHit(int color, int weapon)
	{
		List<Vector3> pos = new List<Vector3>();
		if (weapon == 3)
			return pos;

		
		foreach(Enemy d in dudes)
		{
			if(d.tile.color == color)
		    {
				if(d.GetHit(weapon))
				{
					SFX.singleton.PlaySound(0);	
					pos.Add(d.tile.transform.position);
					d.tile.free = true;
					if (d.target != null)
						d.target.free = true;
					kill.Add(d);
				}
			}
		}
		
		
		if(kill.Count > 0)
		{
			SFX.singleton.PlaySound(4);
			foreach(Enemy d in kill)
				dudes.Remove(d);
			kill.Clear();
		}

		return pos;
	}
	
	public void PlanMove()
	{
		 int j, k;
		 foreach(Enemy d in dudes)
		 {
			if( d.InRange() )
				continue;
			Tile tl = null;
			if(big && d.tile.zoneID == range[d.tile.range].Count / 2) // Half Row in the Big Zone
			{
				if(range[d.tile.range - 1][d.tile.zoneID - 1].free)
					tl = range[d.tile.range - 1][d.tile.zoneID - 1];
			}
			else if(d.tile.zoneID  != 0 && d.tile.zoneID != range[d.tile.range].Count - 1) // Tiles with two options
			{
				
				if( big && d.tile.zoneID > range[d.tile.range].Count/2 )
					k = 1;
				else
					k = 0;

				if(range[d.tile.range - 1][d.tile.zoneID - 1 - k].free)
					tl = range[d.tile.range - 1][d.tile.zoneID - 1 - k];
				else if(range[d.tile.range - 1][d.tile.zoneID - k].free)
					tl = range[d.tile.range - 1][d.tile.zoneID - k];
			}
			else   // First and last Row
			{
				if(d.tile.zoneID == 0)
					k = 0;
				else
					k = range[d.tile.range - 1].Count - 1;
				if(range[d.tile.range - 1][k].free)
					tl = range[d.tile.range - 1][k];
			}
			
			if(tl != null)
			{
				d.tile.free = true;
				d.target = tl;
				tl.free = false;
			}
			else
			{
				d.tile.free = false;
			}
					
		 }

	}
	
	public int CheckCastleHit()
	{
		int dmg = 0;
		foreach(Enemy d in dudes)
		{
			if(d.Attack ())
			{
				dmg++;
			}
		}
		return dmg;
	}
	
	public void Spawn()
	{
		Random.seed = (int)System.DateTime.Now.Ticks;
		int pos = Random.Range(0, range[4].Count);
		int aux = pos;

		while (!range[4][pos].free)
		{
			pos = (pos + 1) % range[4].Count;
			if (pos == aux)
				return;
		}
		
		

		Enemy obj = (Enemy)((GameObject)(GameObject.Instantiate(enemy,range[4][pos].transform.position, Quaternion.identity))).GetComponent("Enemy");
		obj.tile = range[4][pos];
		if(obj.transform.position.x > 5f)
			obj.transform.localScale = new Vector3( -obj.transform.localScale.x, obj.transform.localScale.y, obj.transform.localScale.z);
		range[4][pos].free = false;
		dudes.Add(obj);
	}
}
