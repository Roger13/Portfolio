﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SFX : MonoBehaviour 
{
	public static SFX singleton = null;
	public List<AudioClip> sfxs;
	public List<float> time;
	public List<bool> playing;
	
	void Awake()
	{
		if(singleton == null)
			singleton = this;
		time = new List<float> ();
	}
	

	// Use this for initialization
	void Start () 
	{
		int i;
		for(i=0; i<sfxs.Count; i++)
		{
			time.Add(0f);
			playing.Add (false);
		}
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		int i;
		for(i=0; i< time.Count; i++)
		{
			if(playing[i])
			{
				if( time[i] > 0 )
					time[i] = time[i] - Time.deltaTime;
				else
					playing[i] = false;
			}
		}
	
	}
	
	public void PlaySound(int n)
	{
		if(n < sfxs.Count)
		{
			if(! playing[n])
			{
				audio.clip = sfxs[n];
				time[n] = sfxs[n].length;
				playing[n] = true;
				audio.Play();
			}
		}
	}
}