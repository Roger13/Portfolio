﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class CastleShoot : MonoBehaviour {

	public Object arrows;
	public Object flame;
	public List<Transform> positions;

	// Use this for initialization
	void Start () 
	{

	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void CastleShootTargets (int attack, List<Vector3> positions, int pos) 
	{
		switch (attack) {
			// Arrows
			case 1: foreach(Vector3 destination in positions)
				ShootArrow(destination.x,destination.y, pos);
			break;
			// FireBalls
			case 2: foreach(Vector3 destination in positions)
				ThrowFireBalls(destination.x,destination.y, pos);
			break; 
		};
	}

	// Generate a single arrow burst and give it its destination
	public void ShootArrow (float x, float y, int pos)
	{
		GameObject firedArrows = (GameObject) Instantiate (arrows, new Vector3 (0, 0, -2), Quaternion.identity);
		((ProjectilesMovement)firedArrows.GetComponent("ProjectilesMovement")).start = positions[pos].position;
		firedArrows.GetComponent<ProjectilesMovement> ().x = x;
		firedArrows.GetComponent<ProjectilesMovement> ().y = y;
	}

	// Generate a single fireball and give it its destination
	public void ThrowFireBalls (float x, float y, int pos)
	{
		
		GameObject fireBall = (GameObject) Instantiate (flame, new Vector3 (0, 0, -2), Quaternion.identity);

		((ProjectilesMovement)fireBall.GetComponent("ProjectilesMovement")).start = positions[pos].position;
		
		fireBall.GetComponent<ProjectilesMovement> ().x = x;
		fireBall.GetComponent<ProjectilesMovement> ().y = y;
	}
}
