﻿using UnityEngine;
using System.Collections;

public class ChangeScene : MonoBehaviour {

	public string GameScene;
	public bool exit;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKeyDown ("escape")) 
		{
			Application.Quit();
		}
		
	}

	void OnMouseDown () 
	{	if(!exit)
			Application.LoadLevel(GameScene);
		else
			Application.Quit ();
	}
	
}
