﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapScript : MonoBehaviour 
{
	public List<Tile> hexagons;
	public List<Zone> zones;
	public GameObject hxg;
	public CastleShoot castle;
	public int curRange;
	public int curZone; // Clockwise, 0 = NE, 1 = SE, 2 = SW, 3 = NW
	public int curZone2;

	public int hexagonCount = 80;
	public int halfCount = 40;

	bool beated = false;

	public GameObject input;
	public GameObject sound;

	void Start () 
	{
		BuildZones();
		SortZones();
		ShuffleZones();
		
		input.SetActive(true);
		sound.SetActive(true);
	}
	
	public void SortZones()
	{
		int i;
		for(i=0; i<4; i++)
		{
			zones[i].SortTiles();
		}
	}
	
	public void ShuffleZones()
	{
		curZone = 0;
		curZone2 = -1;

		int i;
		for(i=0; i<4; i++)
		{
			zones[i].ShuffleTiles();
			if(i == curZone)
				zones[i].Appear();
			else
				zones[i].Fade();
		}
		
	}
	
	public void BuildZones() // Generate Heaxgon Tiles and Initialize their range and ID
	{
		Vector3 pos = hxg.transform.localPosition;
		Vector3 org = new Vector3(pos.x, pos.y, pos.z);
		pos = new Vector3(0, 0, 0);
		Quaternion rot = new Quaternion(0, 0, 0, 0);
		
		
		zones[0].big = true;
		zones[1].big = false;
		zones[2].big = true;
		zones[3].big = false;
		
		// Build hexagonal grid
		int i, j, z, w;
		w = 0;
		for(i=0; i<5; i++)
		{
			z = i + 5;
			for(j=0; j<z+1; j++)
			{
				pos.x += 4.43f;	
				var obj = Object.Instantiate(hxg, new Vector3(org.x + pos.x, org.y + pos.y, org.z), rot);
				((GameObject)obj).transform.parent = transform;
				InitializeHexagon(obj, i, j, z, w);
				w++;
			}
			org.x -= 2.215f;	
			pos.x = 0;
			pos.y -= 3.84f;
		}
		
		org.x += 4.43f;
		
		for(i=5; i<10; i++)
		{
			z = 14 - i;
			for(j=0; j<z+1; j++)
			{
				pos.x += 4.43f;	
				var obj = Object.Instantiate(hxg, new Vector3(org.x + pos.x, org.y + pos.y, org.z), rot);
				((GameObject)obj).transform.parent = transform;
				InitializeHexagon(obj, i, j, z, w);
				w++;
			}
			org.x += 2.215f;	
			pos.x = 0;
			pos.y -= 3.84f;
		}
		
	}
	
	public void InitializeHexagon(Object obj, int i, int j, int z, int w) // Set Tile ID and range and register in its zone
	{
		SpriteRenderer spt = (SpriteRenderer)(((GameObject)obj).GetComponent("SpriteRenderer"));
		Tile tl = (Tile)(((GameObject)obj).GetComponent("Tile"));
		
		
		if(i == 0 || i == 9 || j == 0 || j == z )
		{
			spt.color = Color.green;
			tl.range = 4;
		}
		else if(i == 1 || i == 8 || j == 1 || j == z - 1 )
		{
			spt.color = Color.blue;
			tl.range = 3;
		}
		else if(i == 2 || i == 7 || j == 2 || j == z - 2 )
		{
			spt.color = Color.yellow;
			tl.range = 2;
		}
		else if(i == 3 || i == 6 || j == 3 || j == z - 3 )
		{
			spt.color = Color.red;	
			tl.range = 1;
		}
		else
		{
			Object.Destroy(obj);
		}
		
		hexagons.Insert(w, tl);
		tl.ID = w;
		
		if( w < halfCount ) // NW or NE
		{
			if( (0 == w) || ((5 < w) && (w < 8)) || ((12 < w) && (w < 16))
				|| ((20 < w) && (w < 25)) || ((29 < w) && (w < 35)) )
				zones[3].Assign(tl);
			else
				zones[0].Assign(tl);
		}
		else // SE or SW
		{
			if( ((44 < w) && (w < 50)) || ((54 < w) && (w < 59)) || ((63 < w) && (w < 67))
				|| ((71 < w) && (w < 74)) || (w == 79) )
				zones[1].Assign(tl);
			else
				zones[2].Assign(tl);
			
		}		
		
		
	}

	public void RangeMe(int range)
	{
		curRange = range;
	}

	public void Move()
	{
		zones[curZone].PlanMove();
		zones[curZone].Move();
	}

	public void Shine ()
	{
		zones[curZone].Fade();
		curZone = (curZone + 1) % 4;
		zones[curZone].Appear();
	}

	public void NextBeat ()
	{
		curZone2 = (curZone2 + 1) % 4;
		beated = false;
	}

	public bool BeatMe(int color, int weapon)
	{	
		if (beated)
			return false;
	
		List<Vector3> hits = zones[curZone2].CheckEnemiesHit(color, weapon); // kill them if life == 0
		castle.CastleShootTargets(weapon, hits, curZone2);
		zones[curZone].CheckCastleHit();
		zones[curZone2].Spawn();
		beated = true;

		return hits.Count > 0;
	}
	
	
}