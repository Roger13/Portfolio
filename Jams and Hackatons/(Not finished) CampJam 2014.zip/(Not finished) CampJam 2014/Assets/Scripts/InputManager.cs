﻿using UnityEngine;
using System.Collections;

public class InputManager : MonoBehaviour {
	
	// Rhythm shit
	public static float audioDelay = 0.22f;
	public static float tick = 0.5216484089723526343244653103808f;
	public static float halfTick;
	float delta = 0.01f;
	public static float time;
	bool commandGiven = false;
	bool ticked = false;
	bool nextBeat = false;
	public RhythmIndicator RhyIndicator;

	public enum Weapons : int {Unarmed, Arrow, Fireball, Missed};
	public enum Collor : int {Verde, Vermelho, Azul, Amarelo};
	Weapons armed = Weapons.Unarmed;

	// Map Shit
	public MapScript map;
	public static bool move = false;
	int combo = 0;
	int range = 0;
	int maxRange = 3;
	int threshold = 2;

	public CameraScript camera;

	// Use this for initialization
	void Start () {
		halfTick = tick / 2;
		time = tick - 0.162f;
	}
	
	// Update is called once per frame
	void Update () {
		time += Time.deltaTime;
	}

	void LateUpdate () {
		if (time > halfTick && !nextBeat && !move)
		{
			map.NextBeat();
			nextBeat = true;
		}

		if (time > tick)
		{
			gameObject.audio.Play();

			if (!move)
				map.Move();
			else
				map.Shine();
			move = !move;

			time -= tick;
			nextBeat = false;
		}

		if (time - audioDelay < delta || time - audioDelay > tick - delta)
		{
			InputHandler();

			ticked = true;
		}
		else
		{
			if (ticked)
			{
				if (!commandGiven)
				{
					//Debug.Log ("No command");
					ComboBreaker();
					if (armed == Weapons.Unarmed)
					{
						armed = Weapons.Missed;
						map.BeatMe((int)Collor.Azul, (int)Weapons.Missed);
					}
					else
						armed = Weapons.Unarmed;
				}
				ticked = false;
				commandGiven = false;
			}
		}
	}

	void InputHandler ()
	{
		if (commandGiven)
			return;

		// Get Direction
		if (Input.GetButtonDown("Verde"))
		{
			if (armed == Weapons.Unarmed || armed == Weapons.Missed)
				ComboBreaker();
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				CheckCombo(map.BeatMe((int)Collor.Verde, (int)armed));
				armed = Weapons.Unarmed;
				commandGiven = true;
				//Debug.Log ("Verde");
			}
		}
		if (Input.GetButtonDown("Vermelho"))
		{
			if (armed == Weapons.Unarmed || armed == Weapons.Missed)
				ComboBreaker();
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				CheckCombo(map.BeatMe((int)Collor.Vermelho, (int)armed));
				armed = Weapons.Unarmed;
				commandGiven = true;
				//Debug.Log ("Vermelho");
			}
		}
		if (Input.GetButtonDown("Azul"))
		{
			if (armed == Weapons.Unarmed || armed == Weapons.Missed)
				ComboBreaker();
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				CheckCombo(map.BeatMe((int)Collor.Azul, (int)armed));
				armed = Weapons.Unarmed;
				commandGiven = true;
				//Debug.Log ("Azul");
			}
		}
		if (Input.GetButtonDown("Amarelo"))
		{
			if (armed == Weapons.Unarmed || armed == Weapons.Missed)
				ComboBreaker();
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				CheckCombo(map.BeatMe((int)Collor.Amarelo, (int)armed));
				armed = Weapons.Unarmed;
				commandGiven = true;
				//Debug.Log ("Amarelo");
			}
		}

		// Get Weapon		
		if (Input.GetButtonDown("Arrow"))
		{
			if (armed != Weapons.Unarmed)
			{
				ComboBreaker();
				map.BeatMe((int)Collor.Azul, (int)Weapons.Missed);
			}
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				commandGiven = true;
				armed = Weapons.Arrow;
				//Debug.Log ("Arrow");
			}
		}
		if (Input.GetButtonDown("Fireball"))
		{
			if (armed != Weapons.Unarmed)
			{
				ComboBreaker();
				map.BeatMe((int)Collor.Azul, (int)Weapons.Missed);
			}
			else
			{
				RhyIndicator.InstantiateCorrect();
				((SpriteRenderer)gameObject.renderer).color = Color.black;
				commandGiven = true;
				armed = Weapons.Fireball;
				//Debug.Log ("Fireball");
			}
		}

		if (Input.GetButtonDown("Debug"))
		{
		}
	}

	void CheckCombo (bool hit)
	{
		if (hit)
		{
			combo++;
			if (combo >= threshold)
			{
				threshold *= 2;
				if (range < maxRange)
				{
					range++;
					camera.ChangeRange(1);
				}
			}
		}
	}

	void ComboBreaker ()
	{
		((SpriteRenderer)gameObject.renderer).color = Color.red;
		commandGiven = true;
		combo = 0;
		threshold = 2;
		camera.ChangeRange(-range);
		range = 0;
		RhyIndicator.InstantiateIncorrect();
	}

	public float getTimer ()
	{
		if (time > halfTick)
			return 0;

		return time;
	}
}
