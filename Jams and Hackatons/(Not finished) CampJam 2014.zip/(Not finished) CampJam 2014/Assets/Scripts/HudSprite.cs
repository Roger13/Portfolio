﻿using UnityEngine;
using System.Collections;

public class HudSprite : MonoBehaviour {
	public float xOffset;
	public bool fromRight;
	public float yOffset;
	public bool fromTop;
	public float baseScale;

	void LateUpdate ()
	{
		float x = xOffset * CameraScript.mainCamera.pixelWidth;
		if (fromRight)
			x += CameraScript.mainCamera.pixelWidth;

		float y = yOffset * CameraScript.mainCamera.pixelHeight;
		if (fromTop)
			y += CameraScript.mainCamera.pixelHeight;

		Vector3 pos = CameraScript.mainCamera.ScreenToWorldPoint(new Vector3(x,y,-3));
		pos.z = -6;
		transform.localPosition = pos;

		transform.localScale = Vector3.one * baseScale * CameraScript.mainCamera.orthographicSize / 8;
	}
}
