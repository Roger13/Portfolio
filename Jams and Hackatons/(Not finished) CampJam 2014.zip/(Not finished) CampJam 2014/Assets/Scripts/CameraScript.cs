using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour {
	
	public static Camera mainCamera;
	public int range;

	private float [] sizes; // Holds the fields of views for each range level
	private float curSize;
	private int deltaRange; // -1 if negative, 0 if stable, 1 if positive

	bool rescaling = false;
	int ticks = 0;

	// Use this for initialization	
	void Start () 
	{
		CameraScript.mainCamera = this.camera;
		range = 0;

		sizes = new float[4] {8, 12, 16, 20}; // Check
		curSize = sizes[range];
		deltaRange = 0;	
	}

	// Update is called once per frame
	void LateUpdate () {
		curSize = sizes[range];
		//Controls the transitions between diferent ranges

		if (rescaling)
		{
			curSize = Mathf.Lerp (sizes[range - deltaRange], sizes[range], InputManager.time / InputManager.tick);

			if (InputManager.time > InputManager.tick)
				rescaling = false;
		}

		// Make camera bounce with Sin
		mainCamera.orthographicSize = 0.3f * (sizes[range] / 8) * Mathf.Sin(InputManager.time * Mathf.PI/InputManager.tick) + curSize;
	}
	
	// Changes the camera range 
	// (positive numbers increases range and negative ones decreases)
	public void ChangeRange (int deltaRange) {
		if (deltaRange == 0)
			return;

		range += deltaRange;
		ticks = 0;
		rescaling = true;
		this.deltaRange = deltaRange;
	}
}
