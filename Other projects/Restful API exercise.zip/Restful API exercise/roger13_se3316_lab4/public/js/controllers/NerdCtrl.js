angular.module('NerdCtrl', []).controller('NerdController', function($scope) {

    $scope.tagline = 'Here you can share your posts!';

});