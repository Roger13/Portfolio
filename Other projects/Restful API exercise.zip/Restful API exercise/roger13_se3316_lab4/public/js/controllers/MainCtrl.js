angular.module('MainCtrl', []).controller('MainController', function($scope) {

    $scope.tagline = 'Single page web application!';   

});
