#include <stdio.h>

int main(){
	int nSpritesLarg, nSpritesAlt;
	int Larg, Alt;	

	setbuf(stdout, NULL);
	
	printf("Digite as dimensoes da imagem: ");
	scanf("%d %d", &Larg, &Alt);
	printf("\nDigite quantos sprites cada dimens�o tem: ");
	scanf("%d %d", &nSpritesLarg, &nSpritesAlt);
	
	//Larg
	while(Larg % 4 != 0){
		Larg+=nSpritesLarg;
	}

	//Alt
	while(Alt % 4 != 0){
		Alt+=nSpritesAlt;
	}
	
	printf("\nOs valores divis�veis por 4 sao:\n");
	printf("%d x %d", Larg, Alt);
	return 0;
}